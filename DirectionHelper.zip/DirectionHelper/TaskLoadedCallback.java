package com.oruauto.DirectionHelper;

public interface TaskLoadedCallback {
    void onTaskDone(Object... values);
}